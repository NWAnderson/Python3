from django.apps import AppConfig


class DiscgolfConfig(AppConfig):
    name = 'discgolf'
