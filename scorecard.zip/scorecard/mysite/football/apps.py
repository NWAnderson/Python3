from django.apps import AppConfig


class FootballConfig(AppConfig):
    name = 'football'
