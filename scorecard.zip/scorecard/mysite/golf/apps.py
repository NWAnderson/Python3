from django.apps import AppConfig


class GolfConfig(AppConfig):
    name = 'golf'
