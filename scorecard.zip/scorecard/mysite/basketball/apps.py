from django.apps import AppConfig


class BasketballConfig(AppConfig):
    name = 'basketball'
